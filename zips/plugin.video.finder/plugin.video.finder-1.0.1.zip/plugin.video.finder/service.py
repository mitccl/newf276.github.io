from resources.lib.service import ServiceMonitor

if __name__ == '__main__':
    ServiceMonitor()

# TheMovieDB Helper [![License](https://img.shields.io/badge/License-GPLv3-blue)](https://github.com/jurialmunkey/plugin.video.finder/blob/master/LICENSE.txt)

See [Finder Wiki](https://github.com/jurialmunkey/plugin.video.finder/wiki) for usage
